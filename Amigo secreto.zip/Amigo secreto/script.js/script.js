let participantes = [];

function agregarParticipante() {
  const input = document.getElementById("nombreInput");
  const nombre = input.value.trim();

  if (nombre === "") {
    alert("Por favor, escribe un nombre.");
    return;
  }

  if (participantes.includes(nombre)) {
    alert("Este nombre ya está en la lista.");
    return;
  }

  participantes.push(nombre);
  input.value = "";
  mostrarLista();
}

function mostrarLista() {
  const lista = document.getElementById("listaParticipantes");
  lista.innerHTML = "";

  participantes.forEach((nombre) => {
    const li = document.createElement("li");
    li.textContent = nombre;
    lista.appendChild(li);
  });
}

function sortearAmigo() {
  if (participantes.length < 2) {
    alert("Debes añadir al menos 2 participantes.");
    return;
  }

  const indice = Math.floor(Math.random() * participantes.length);
  const nombreSorteado = participantes[indice];

  document.getElementById("resultado").textContent = `🎉 El amigo secreto es: ${nombreSorteado}`;
}

function reiniciar() {
  if (confirm("¿Seguro que deseas reiniciar la lista?")) {
    participantes = [];
    document.getElementById("listaParticipantes").innerHTML = "";
    document.getElementById("resultado").textContent = "";
  }
}
